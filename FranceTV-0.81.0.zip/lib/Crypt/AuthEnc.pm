package Crypt::AuthEnc;

use strict;
use warnings;
our $VERSION = '0.060';

### not used

1;

=pod

=head1 NAME

Crypt::AuthEnc - [internal only]

=cut
